const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('haloDesktop', {
  openExternal: (url) => ipcRenderer.invoke('halo:open-external', url)
});
