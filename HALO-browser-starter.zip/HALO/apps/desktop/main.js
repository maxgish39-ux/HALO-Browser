const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('node:path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 760,
    minHeight: 560,
    backgroundColor: '#090b10',
    title: 'HALO Browser',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webviewTag: true
    }
  });

  win.loadFile('index.html');
  win.webContents.setWindowOpenHandler(({ url }) => {
    // Do not spawn uncontrolled browser windows. External links can be opened
    // by the browser UI's own navigation flow in a future release.
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  ipcMain.handle('halo:open-external', async (_event, url) => {
    try {
      const parsed = new URL(url);
      if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
        await shell.openExternal(parsed.href);
        return true;
      }
    } catch {}
    return false;
  });

  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
