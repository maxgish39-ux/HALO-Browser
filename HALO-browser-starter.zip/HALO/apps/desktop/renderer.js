const tabsRoot = document.getElementById('tabs');
const stage = document.getElementById('browser-stage');
const address = document.getElementById('address');
const startPage = document.getElementById('start-page');
let tabs = [];
let activeId = null;
let nextId = 1;

function normalizeInput(input) {
  const value = input.trim();
  if (!value) return null;
  if (/^https?:\/\//i.test(value)) return value;
  if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(value) && !value.includes(' ')) return `https://${value}`;
  return `https://www.google.com/search?q=${encodeURIComponent(value)}`;
}
function activeTab() { return tabs.find(t => t.id === activeId); }

function createTab(url = null) {
  const id = nextId++;
  const view = document.createElement('webview');
  view.className = 'webview';
  view.setAttribute('partition', 'persist:halo');
  view.setAttribute('allowpopups', 'false');
  view.setAttribute('webpreferences', 'contextIsolation=yes,sandbox=yes');
  view.src = url || 'about:blank';
  view.style.display = 'none';
  stage.appendChild(view);
  const tab = { id, title: 'New tab', url: url || '', view };
  tabs.push(tab);
  view.addEventListener('page-title-updated', e => { tab.title = e.title || 'New tab'; renderTabs(); });
  view.addEventListener('did-navigate', e => { tab.url = e.url; if (activeId === id) address.value = e.url; });
  view.addEventListener('did-navigate-in-page', e => { tab.url = e.url; if (activeId === id) address.value = e.url; });
  view.addEventListener('did-start-loading', () => { if (activeId === id) document.body.classList.add('loading'); });
  view.addEventListener('did-stop-loading', () => { if (activeId === id) document.body.classList.remove('loading'); });
  view.addEventListener('new-window', e => {
    // New windows are converted to a new HALO tab instead of a separate window.
    const newTab = createTab(e.url);
    activateTab(newTab.id);
  });
  activateTab(id);
  return tab;
}
function renderTabs() {
  tabsRoot.replaceChildren();
  for (const tab of tabs) {
    const item = document.createElement('div');
    item.className = `tab ${tab.id === activeId ? 'active' : ''}`;
    const select = document.createElement('button');
    select.className = 'tab-select';
    select.textContent = tab.title.length > 22 ? tab.title.slice(0, 22) + '…' : tab.title;
    select.title = tab.title;
    select.addEventListener('click', () => activateTab(tab.id));
    const close = document.createElement('button');
    close.className = 'tab-close';
    close.textContent = '×';
    close.title = 'Close tab';
    close.addEventListener('click', e => { e.stopPropagation(); closeTab(tab.id); });
    item.append(select, close);
    tabsRoot.appendChild(item);
  }
}
function activateTab(id) {
  activeId = id;
  for (const tab of tabs) tab.view.style.display = tab.id === id ? 'flex' : 'none';
  const tab = activeTab();
  const isStart = !tab || !tab.url || tab.url === 'about:blank';
  startPage.style.display = isStart ? 'flex' : 'none';
  address.value = isStart ? '' : tab.url;
  renderTabs();
}
function closeTab(id) {
  const index = tabs.findIndex(t => t.id === id);
  if (index < 0) return;
  tabs[index].view.remove();
  tabs.splice(index, 1);
  if (!tabs.length) createTab();
  else if (activeId === id) activateTab(tabs[Math.max(0, index - 1)].id);
  else renderTabs();
}
function navigate(raw) {
  const url = normalizeInput(raw);
  if (!url) return;
  let tab = activeTab();
  if (!tab) tab = createTab();
  tab.url = url;
  tab.title = 'Loading…';
  tab.view.src = url;
  startPage.style.display = 'none';
  address.value = url;
  renderTabs();
}
document.getElementById('new-tab').addEventListener('click', () => createTab());
document.getElementById('nav-form').addEventListener('submit', e => { e.preventDefault(); navigate(address.value); });
document.getElementById('hero-form').addEventListener('submit', e => { e.preventDefault(); navigate(document.getElementById('hero-address').value); });
document.getElementById('back').addEventListener('click', () => { const t = activeTab(); if (t?.view.canGoBack()) t.view.goBack(); });
document.getElementById('forward').addEventListener('click', () => { const t = activeTab(); if (t?.view.canGoForward()) t.view.goForward(); });
document.getElementById('reload').addEventListener('click', () => { const t = activeTab(); if (t) t.view.reload(); });
document.getElementById('home').addEventListener('click', () => { const t = activeTab(); if (t) { t.url = ''; t.view.src = 'about:blank'; } activateTab(activeId); });
document.getElementById('bookmark').addEventListener('click', () => alert('Bookmarks are planned for the next HALO milestone.'));
document.getElementById('menu').addEventListener('click', () => alert('HALO Browser 0.1.0\nA cross-platform browser project. Settings, privacy controls and downloads are coming next.'));
document.querySelectorAll('[data-url]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.url)));
window.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'l') { e.preventDefault(); address.focus(); address.select(); }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 't') { e.preventDefault(); createTab(); }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'w') { e.preventDefault(); closeTab(activeId); }
});
createTab();
