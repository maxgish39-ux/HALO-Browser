package dev.halo.browser

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var address: EditText
    private lateinit var progress: TextView
    private val bg = Color.rgb(9, 11, 16)
    private val panel = Color.rgb(20, 23, 34)
    private val violet = Color.rgb(154, 139, 255)
    private val text = Color.rgb(240, 242, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = TextView(this).apply {
            text = "◉  H A L O"
            textSize = 19f
            setTextColor(violet)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 12, 18, 8)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 52))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 8)
            setBackgroundColor(panel)
        }
        fun button(label: String, action: () -> Unit): Button =
            Button(this).apply {
                text = label
                textSize = 15f
                setTextColor(text)
                setBackgroundColor(panel)
                setOnClickListener { action() }
            }
        nav.addView(button("‹") { if (::webView.isInitialized && webView.canGoBack()) webView.goBack() },
            LinearLayout.LayoutParams(44, 48))
        nav.addView(button("›") { if (::webView.isInitialized && webView.canGoForward()) webView.goForward() },
            LinearLayout.LayoutParams(44, 48))
        address = EditText(this).apply {
            singleLine = true
            textSize = 14f
            setTextColor(text)
            setHintTextColor(Color.GRAY)
            hint = "Search or enter address"
            setPadding(12, 0, 12, 0)
            setBackgroundColor(bg)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                    navigate(address.text.toString())
                    true
                } else false
            }
        }
        nav.addView(address, LinearLayout.LayoutParams(0, 44, 1f))
        nav.addView(button("↻") { webView.reload() }, LinearLayout.LayoutParams(44, 48))
        root.addView(nav)

        progress = TextView(this).apply {
            text = "READY"
            textSize = 10f
            setTextColor(violet)
            setPadding(14, 4, 14, 4)
        }
        root.addView(progress)

        webView = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val scheme = request.url.scheme?.lowercase()
                    return scheme != "https" && scheme != "http"
                }
                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    address.setText(url ?: "")
                    progress.text = "LOADING"
                }
                override fun onPageFinished(view: WebView, url: String?) {
                    address.setText(url ?: "")
                    progress.text = "HALO / READY"
                }
            }
            webChromeClient = WebChromeClient()
        }
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        webView.loadUrl("https://www.google.com")
    }

    private fun navigate(input: String) {
        val value = input.trim()
        if (value.isEmpty()) return
        val url = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(" ") || !value.contains(".") -> "https://www.google.com/search?q=" +
                java.net.URLEncoder.encode(value, "UTF-8")
            else -> "https://$value"
        }
        if (!url.startsWith("https://") && !url.startsWith("http://")) {
            Toast.makeText(this, "Only web addresses are supported", Toast.LENGTH_SHORT).show()
            return
        }
        webView.loadUrl(url)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
