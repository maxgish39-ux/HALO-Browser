const features = [
  { number: "01", title: "Your web, your way", text: "A considered interface designed to keep the web in focus, not the browser chrome." },
  { number: "02", title: "One project, many screens", text: "Desktop and Android builds, developed in the open and shaped by the community." },
  { number: "03", title: "Open by design", text: "Public source, transparent releases, and a roadmap the community can help build." },
];

export default function Home() {
  return (
    <main>
      <nav className="nav">
        <a className="brand" href="#"><span>◉</span> HALO <small>BROWSER</small></a>
        <div className="navlinks"><a href="#features">Features</a><a href="https://github.com/" target="_blank" rel="noreferrer">GitHub ↗</a></div>
      </nav>
      <section className="hero">
        <div className="glow glowA" /><div className="glow glowB" />
        <div className="eyebrow"><i /> A NEW WINDOW TO THE WEB</div>
        <div className="symbol">◉</div>
        <h1>Move through<br /><em>the web.</em></h1>
        <p>A browser project for people who want less noise<br className="desktopBreak" /> and more room to explore.</p>
        <div className="actions">
          <a className="primary" href="https://github.com/" target="_blank" rel="noreferrer">Explore the source <span>↗</span></a>
          <a className="secondary" href="#features">Discover HALO <span>↓</span></a>
        </div>
        <div className="platforms"><span>◫ WINDOWS</span><span>▣ ANDROID</span><span>⌘ OPEN SOURCE</span></div>
      </section>
      <section className="features" id="features">
        <div className="sectionhead"><div className="eyebrow">BUILT WITH INTENTION</div><h2>A calmer kind<br/>of browsing.</h2></div>
        <div className="featurelist">{features.map((f) => <article key={f.number}><span>{f.number}</span><div><h3>{f.title}</h3><p>{f.text}</p></div><b>↗</b></article>)}</div>
      </section>
      <footer><a className="brand" href="#"><span>◉</span> HALO</a><span>EARLY DEVELOPMENT · 0.1.0</span><span>BUILT IN THE OPEN.</span></footer>
    </main>
  );
}
