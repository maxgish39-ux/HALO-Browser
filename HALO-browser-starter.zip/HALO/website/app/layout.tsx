import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HALO Browser — Move through the web",
  description: "HALO is a cross-platform browser project built for a more focused web.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
