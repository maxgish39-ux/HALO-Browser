# HALO Browser

A cross-platform browser project with a custom dark interface:
- **Desktop:** Electron + Chromium
- **Android:** Kotlin + Android WebView
- **Website:** Next.js, ready for Vercel
- **Release:** GitHub Actions starter workflow

> This is an initial working foundation, not a production-hardened browser yet. Before a public release, add automated tests, security review, privacy policy, icon assets, signing, and platform-specific QA.

## Repository layout

```text
HALO/
├── apps/
│   ├── desktop/       Electron desktop browser
│   └── android/       Native Android browser
└── website/           Next.js landing page for Vercel
```

## Desktop quick start

Requirements: Node.js 20+ and npm.

```bash
cd apps/desktop
npm install
npm start
```

Build installers:

```bash
npm run build
```

Packaged outputs are written to `apps/desktop/dist/`. Build Windows packages on Windows for the most reliable results.

## Android quick start

Open `apps/android/` in Android Studio, allow Gradle sync, then run the `app` configuration on a device or emulator. The project uses Android's system WebView, so the installed Android System WebView / Chrome provider supplies the rendering engine.

To build an APK from a machine with Android SDK configured:

```bash
cd apps/android
./gradlew assembleDebug
```

The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Website / Vercel

Import the repository into GitHub, then import the `website` directory as the Vercel project root. Alternatively, set the Vercel Root Directory to `website`.

```bash
cd website
npm install
npm run dev
```

## GitHub release plan

1. Push this repository to GitHub.
2. Test desktop on Windows and Android on real devices.
3. Add release notes and a privacy policy.
4. Configure code signing for Windows and Android signing for Play distribution.
5. Create a GitHub Release; attach the desktop installer and signed Android APK/AAB.
6. Deploy `website/` to Vercel and link its download buttons to GitHub Releases.

## Current functionality

- Desktop Chromium-backed browsing via Electron `<webview>` surfaces
- Multiple tabs, back/forward, reload, home, URL/search bar
- Android WebView browsing with URL/search, back, forward, reload, home
- Responsive dark HALO landing page
- Basic GitHub Actions desktop build workflow

## Important next milestones

- Persistent bookmarks, history, downloads, and settings
- Private browsing mode and clear-data controls
- Permission prompts for camera, microphone, location, notifications, and downloads
- Popup/new-window policy and external protocol handling
- Safer ad/tracker blocking with maintainable filter lists
- Browser security review, tests, accessibility, and release signing
